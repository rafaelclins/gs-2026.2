# GS2026.2 — CitizenTech: Assistente de Mobilidade Urbana

Projeto de **Generative Systems (GS 2026.2)** que implementa um pipeline **RAG** sobre a base documental da Linha 714 de transporte público, com interface de chat em Gradio, agente com ferramentas, guardrails de segurança e avaliação com RAGAS.

**Tema:** Mobilidade  
**Turma/Sala:** 1CCPI  
**Grupo:** Grupo X

## Integrantes

| Integrante | RM |
|---|---|
| Eric dos Santos Mendes da Silva | 569528 |
| Rafael Côrtes Lins | 570588 |
| Tom Stringasci Albuquerque Coelho Morais | 568844 |

---

## 1. Visão Geral

Sistema RAG (Retrieval-Augmented Generation) que consulta base documental municipal sobre transporte público (Linha 714), responde com citações de fonte e prova sua precisão via avaliação RAGAS.

**Problema:** Cidadãos não sabem se informações sobre ônibus estão atualizadas (pontos interditados, mudanças de tarifa).

**Solução:** Assistente que recupera documentos oficiais, compara datas e responde apenas com evidência rastreável.

---

## 2. Arquitetura do Pipeline

```text
┌──────────────────┐      ┌───────────────────┐      ┌──────────────────┐
│ Base Documental  │─────▶│ Chunking          │─────▶│ Embeddings       │
│ (2 arquivos)     │      │ (2 estratégias)   │      │ (local/ST)       │
└──────────────────┘      └───────────────────┘      └──────────────────┘
                                                              │
                                                              ▼
┌──────────────────┐      ┌───────────────────┐      ┌──────────────────┐
│ Interface        │◀─────│ RAG (LCEL)        │◀─────│ ChromaDB         │
│ (Gradio)         │      │                   │      │                  │
└──────────────────┘      └───────────────────┘      └──────────────────┘
        │                          │
        ▼                          ▼
┌──────────────────┐      ┌───────────────────┐
│ Agente c/        │      │ Guardrails        │
│ Ferramentas      │      │ (3 camadas)       │
└──────────────────┘      └───────────────────┘
        │
        ▼
┌──────────────────┐
│ Avaliação        │
│ (RAGAS)          │
└──────────────────┘
```

---

## 3. Componentes Técnicos

| Componente | Tecnologia | Função |
|------------|------------|--------|
| LLM | NVIDIA NIM (nvidia/nemotron-3-ultra-550b-a55b) | Geração de respostas |
| Embeddings | sentence-transformers local (paraphrase-multilingual-MiniLM-L12-v2) | Vetorização de documentos |
| Vetor DB | ChromaDB | Busca semântica |
| Orquestração | LangChain (LCEL) | Pipeline RAG |
| Agente | LangChain Tools | Decisão de usar ferramentas |
| Interface | Gradio | Chat web |
| Avaliação | RAGAS (Nemotron 3 Ultra via NVIDIA NIM + embeddings locais) | Métricas de qualidade |

---

## 4. Base Documental

### 4.1 Estrutura

| Arquivo | Tipo | Data | Conteúdo |
|---------|------|------|----------|
| `linha_714_itinerario_2024.txt` | Itinerário oficial | 15/03/2024 | Horários, tarifas, pontos ativos |
| `portaria_atualizacao_2025.txt` | Portaria | 22/01/2025 | Interdição de ponto, mudança de tarifa |

### 4.2 Armadilhas Propositais

| Tipo | Descrição | Teste |
|------|-----------|-------|
| **Contradição** | Doc 2024 diz ponto "ATIVO", Doc 2025 diz "INTERDITADO" | "O ponto da Rua das Flores está funcionando?" |
| **Faixa condicional** | Gratuidade só em dias úteis (mudou em 2025) | "Meu pai de 68 anos pode viajar de graça no sábado?" |
| **Detalhe escondido** | Ponto alternativo no item 2 da portaria | "Onde pego o ônibus se o ponto estiver fechado?" |

---

## 5. Decisões Técnicas

### 5.1 Chunking

| Estratégia | Chunk Size | Overlap | Chunks | Justificativa |
|------------|------------|---------|--------|---------------|
| CharacterTextSplitter | 500 | 50 | 7 | Rápido, mas quebra contexto |
| **RecursiveCharacterTextSplitter** | **1000** | **100** | **4** | **Preserva parágrafos completos** ✅ |

**Escolha:** RecursiveCharacterTextSplitter — mantém portarias inteiras, essencial para comparar datas.

### 5.2 Guardrails

| Guardrail | Implementação | Exemplo |
|-----------|---------------|---------|
| Validação de faixa etária | Verifica regra de gratuidade de idosos/gestantes (só dias úteis, Portaria 047/2025) | Alerta em perguntas de idosos/gestantes em fins de semana |
| Proteção contra alucinação | Prompt: "Se não estiver no contexto, diga 'não sei'" | Nunca inventa horário |
| Sanitização de input | Detecta "ignore instruções anteriores" | Bloqueia prompt injection |

---

## 6. Resultados RAGAS

| Métrica | Valor | Análise |
|---------|-------|---------|
| faithfulness | [preencher após reexecução com a stack NVIDIA NIM] | Respostas ancoradas no contexto |
| answer_relevancy | [preencher após reexecução com a stack NVIDIA NIM] | Perguntas respondidas diretamente |
| context_recall | [preencher após reexecução com a stack NVIDIA NIM] | Recuperou portaria 2025 na maioria dos casos |
| context_precision | [preencher após reexecução com a stack NVIDIA NIM] | Chunks relevantes priorizados |

**Melhoria proposta:** Implementar reranking no retriever para aumentar context_precision em perguntas sobre faixa condicional.

---

## 7. Prints das telas

### 7.1 Chat com resposta e confiança

Pergunta sobre o itinerário, resposta do assistente e o painel de confiança (média 0.6708), marcando que os trechos recuperados aparecem com `doc_id`, trecho e score.

![Chat com resposta e confiança](docs/tela-chat.png)

### 7.2 Painel de fontes consultadas

Fontes ranqueadas pelo retriever (`k=4`) com tipo, data, score de similaridade e trecho recuperado.

![Painel de fontes consultadas (1)](docs/tela-fontes-1.png)

![Painel de fontes consultadas (2)](docs/tela-fontes-2.png)

### 7.3 Avaliação RAGAS

Exemplos de perguntas e respostas com as fontes citadas, seguidos das métricas RAGAS (`faithfulness`, `answer_relevancy`, `context_recall`, `context_precision`) e do diagnóstico exportado para `3_avaliacao_ragas.json`.

![Avaliação RAGAS (1)](docs/tela-ragas-1.png)

![Avaliação RAGAS (2)](docs/tela-ragas-2.png)

---

## 8. Como Executar

1. Abrir notebook no Google Colab
2. Configurar `NVIDIA_API_KEY` nos Secrets (chave de build.nvidia.com)
3. Runtime → Run all
4. Acessar interface Gradio via link público

> **Nota:** Na primeira execução, o modelo de embeddings (~470 MB) é baixado automaticamente para o ambiente do Colab.

---

## 9. Repositório

https://github.com/rafaelclins/gs-2026.2

---

## Link do vídeo

> Adicione aqui o link da demonstração.

[Vídeo de demonstração](https://youtu.be/SEU_LINK_AQUI)

---

*Documentação gerada para GS2026.2 — CitizenTech*
